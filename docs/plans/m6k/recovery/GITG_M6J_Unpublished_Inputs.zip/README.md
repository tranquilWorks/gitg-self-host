# Unpublished M6J inputs

Preserve these source bytes. They are not a tested overlay for main. The completion overlay does not include all earlier compiler/integration changes; reconcile them explicitly. The domain-08 ZIP contains a prepared compiler patch and tests, not authority to overwrite current files. No quality or runtime acceptance is implied. Use the M6K baseline task before edits.
